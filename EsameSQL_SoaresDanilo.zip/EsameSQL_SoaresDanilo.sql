CREATE DATABASE ToysGroup;

Use ToysGroup;
----------------------------------------------------------
CREATE TABLE Category (
	ProductCategoryID INT AUTO_INCREMENT PRIMARY KEY,
	ProductCategoryName VARCHAR(50)
);
    
CREATE TABLE Product (
	ProductID INT AUTO_INCREMENT PRIMARY KEY,
    ProductName VARCHAR(50),
    ProductCategoryID INT,
    PriceList DECIMAL (10,2),
    CONSTRAINT FK_Category_Product FOREIGN KEY (ProductCategoryID)
		REFERENCES Category (ProductCategoryID)
);

CREATE TABLE SalesRegion (
	SalesRegionID INT AUTO_INCREMENT PRIMARY KEY,
    SalesRegionName VARCHAR(59)
);

CREATE TABLE SalesState (
	StateID INT AUTO_INCREMENT PRIMARY KEY,
    StateName VARCHAR (50),
    SalesRegionID INT,
    CONSTRAINT FK_SalesRegion_SalesState FOREIGN KEY (SalesRegionID)
		REFERENCES SalesRegion (SalesRegionID)
);

CREATE TABLE Sales (
	OrderID INT AUTO_INCREMENT PRIMARY KEY,
    OrderDate DATE,
    ProductID INT,
    ProductCategoryID INT,
    StateID INT,
    Quantity INT DEFAULT 0,
	CONSTRAINT FK_Product_Sales FOREIGN KEY (ProductID) REFERENCES Product(ProductID),
	CONSTRAINT FK_ProductCategory_Sales FOREIGN KEY (ProductCategoryID) REFERENCES Category(ProductCategoryID),
	CONSTRAINT FK_SalesState_Sales FOREIGN KEY (StateID) REFERENCES SalesState(StateID)
);

------------------------------------------------------------------------------
# Inserendo i dati al interno delle tabelle

INSERT INTO Category (ProductCategoryName) VALUES
	('Pelusce'),
    ('Puzzle'),
    ('Memory Cards'),
    ('Giocchi da tavola');
 
 INSERT INTO Product (ProductName, ProductCategoryID, PriceList) VALUES
	('Orsacchiotto', 1, 50.00),
    ('Coniglio', 1, 45.50),
    ('Topolino 50 pz', 2, 25.80),
    ('Cars', 3, 15.50),
    ('Harry Potter 150pz', 2, 150.20),
    ('Tombola', 4, 25.50);
    
INSERT INTO SalesRegion (SalesRegionName) VALUES
	('Western Europe'),
    ('South Europe'),
    ('South America'),
    ('Central America');
    
INSERT INTO SalesState (StateName, SalesRegionID) VALUES
	('Argentina', 3),
    ('Italy', 2),
    ('France', 1),
    ('Mexico', 4),
    ('Brasil', 3);
    
INSERT INTO Sales (OrderDate, ProductID, ProductCategoryID, StateID, Quantity) VALUES
	('2025-06-10', 1, 1, 6, 1),
    ('2025-06-11', 3, 2, 8, 4),
    ('2025-06-11', 1, 1, 7, 2),
    ('2025-06-12', 4, 3, 10, 5);
  
ALTER TABLE Sales AUTO_INCREMENT = 1;
SELECT * FROM Sales;

------------------------------------------------------------
# verifica della univocita delle PK

SELECT ProductID, COUNT(*) AS Occorrenze
FROM Product
GROUP BY ProductID
HAVING COUNT(*) > 1;

SELECT ProductCategoryID, COUNT(*) AS Occorrenze
FROM Category
GROUP BY ProductCategoryID
HAVING COUNT(*) > 1;

SELECT SalesRegionID, COUNT(*) AS Occorrenze
FROM SalesRegion
GROUP BY SalesRegionID
HAVING COUNT(*) > 1;

SELECT StateID, COUNT(*) AS Occorrenze
FROM SalesState
GROUP BY StateID
HAVING COUNT(*) > 1;

SELECT OrderID, COUNT(*) AS Occorrenze
FROM Sales
GROUP BY OrderID
HAVING COUNT(*) > 1;

---------------------------------------------------------
# Eelenco delle transazioni indicando nel result set il codice documento, la data, il nome del prodotto,
# la categoria del prodotto, il nome dello stato, il nome della regione di vendita e un campo booleano valorizzato
# in base alla condizione che siano passati più di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False)

SELECT
    s.OrderID AS CodiceDocumento,
    s.OrderDate AS Data,
    p.ProductName AS NomeProdotto,
    c.ProductCategoryName AS CategoriaProdotto,
    st.StateName AS NomeStato,
    sr.SalesRegionName AS RegioneVendita,
    CASE
        WHEN DATEDIFF(CURDATE(), s.OrderDate) > 180 THEN TRUE
        ELSE FALSE
    END AS Over180Days
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
JOIN Category c ON s.ProductCategoryID = c.ProductCategoryID
JOIN SalesState st ON s.StateID = st.StateID
JOIN SalesRegion sr ON st.SalesRegionID = sr.SalesRegionID;

--------------------------------------------------------------------------------
#  prodotti che hanno venduto, in totale, una quantità maggiore della media delle vendite realizzate nell’ultimo anno censito

SELECT
    s.ProductID,
    SUM(s.Quantity) AS TotaleVenduto
FROM Sales s
WHERE YEAR(s.OrderDate) = (
    SELECT MAX(YEAR(OrderDate)) FROM Sales
)
GROUP BY s.ProductID
HAVING SUM(s.Quantity) > (
    SELECT AVG(TotalePerProdotto)
    FROM (
        SELECT SUM(Quantity) AS TotalePerProdotto
        FROM Sales
        WHERE YEAR(OrderDate) = (
            SELECT MAX(YEAR(OrderDate)) FROM Sales
        )
        GROUP BY ProductID
    ) subquery
);

-----------------------------------------------------------------------------------
# soli prodotti venduti e per ognuno di questi il fatturato totale per anno

SELECT
    s.ProductID,
    p.ProductName,
    YEAR(s.OrderDate) AS Anno,
    SUM(s.Quantity * p.PriceList) AS FatturatoTotaleAnnuale
FROM Sales s
JOIN Product p ON s.ProductID = p.ProductID
WHERE s.Quantity > 0
GROUP BY s.ProductID, p.ProductName, YEAR(s.OrderDate)
ORDER BY s.ProductID, Anno;

-------------------------------------------------------------------------------------
# il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente

SELECT
    st.StateName AS Stato,
    YEAR(s.OrderDate) AS Anno,
    SUM(s.Quantity * p.PriceList) AS FatturatoTotale
FROM Sales s
JOIN SalesState st ON s.StateID = st.StateID
JOIN Product p ON s.ProductID = p.ProductID
GROUP BY st.StateName, YEAR(s.OrderDate)
ORDER BY Anno, FatturatoTotale DESC;

--------------------------------------------------------------------------------------
# Il prodotto piu richiesto dal mercato è: "Memory Cards"

SELECT
    c.ProductCategoryName,
    SUM(s.Quantity) AS TotaleRichiesto
FROM Sales s
JOIN Category c ON s.ProductCategoryID = c.ProductCategoryID
GROUP BY c.ProductCategoryName
ORDER BY TotaleRichiesto DESC
LIMIT 1;

----------------------------------------------------------------------------------------
# quali sono i prodotti invenduti?
## Approccio 1: "i prodottiID 1, 3, e 4 sono invenduti

SELECT p.ProductID, p.ProductName
FROM Product p
LEFT JOIN (
    SELECT ProductID, SUM(Quantity) AS TotaleVenduto
    FROM Sales
    GROUP BY ProductID
) vendite ON p.ProductID = vendite.ProductID
WHERE vendite.TotaleVenduto IS NULL OR vendite.TotaleVenduto = 0;

## Approccio 2: I prodotti invenduti sono "Coniglio", Harry Potter 150pz e la Tombola

SELECT MIN(ProductID) AS ProductID, ProductName
FROM Product
GROUP BY ProductName
HAVING MIN(ProductID) NOT IN (SELECT ProductID FROM Sales);

--------------------------------------------------------------
# Creazione delle viste denormalizzate

CREATE VIEW vProdottiDenormalizzati AS
SELECT
    p.ProductID,
    p.ProductName,
    c.ProductCategoryName
FROM Product p
JOIN Category c ON p.ProductCategoryID = c.ProductCategoryID;

SELECT * FROM vProdottiDenormalizzati;

------------------------------------------------------------------
# Vista con le informazioni geografiche

CREATE VIEW vInfoGeografiche AS
SELECT
    st.StateID,
    st.StateName,
    st.SalesRegionID,
    sr.SalesRegionName
FROM SalesState st
JOIN SalesRegion sr ON st.SalesRegionID = sr.SalesRegionID;

SELECT * FROM vInfoGeografiche;